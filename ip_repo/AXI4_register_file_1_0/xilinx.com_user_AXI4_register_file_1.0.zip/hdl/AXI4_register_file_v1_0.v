
`timescale 1 ns / 1 ps

	module AXI4_register_file_v1_0 #
	(
		parameter integer C_S00_AXI_DATA_WIDTH	= 32,
		parameter integer C_S00_AXI_ADDR_WIDTH	= 5
	)
	(
		// RW registers — MicroBlaze reads/writes, fabric reads
		output wire [C_S00_AXI_DATA_WIDTH-1:0] RW_REG0,
		output wire [C_S00_AXI_DATA_WIDTH-1:0] RW_REG1,
		output wire [C_S00_AXI_DATA_WIDTH-1:0] RW_REG2,
		output wire [C_S00_AXI_DATA_WIDTH-1:0] RW_REG3,

		// RO registers — fabric writes (with WE), MicroBlaze reads
		input wire [C_S00_AXI_DATA_WIDTH-1:0] RO_REG0_IN,
		input wire                             RO_REG0_WE,
		input wire [C_S00_AXI_DATA_WIDTH-1:0] RO_REG1_IN,
		input wire                             RO_REG1_WE,
		input wire [C_S00_AXI_DATA_WIDTH-1:0] RO_REG2_IN,
		input wire                             RO_REG2_WE,
		input wire [C_S00_AXI_DATA_WIDTH-1:0] RO_REG3_IN,
		input wire                             RO_REG3_WE,

		// Read strobes: one-cycle pulse when MicroBlaze reads an RO reg
		output wire                            RO_REG0_RDINT,
		output wire                            RO_REG1_RDINT,
		output wire                            RO_REG2_RDINT,
		output wire                            RO_REG3_RDINT,

		// AXI Slave Bus Interface S00_AXI
		input wire  s00_axi_aclk,
		input wire  s00_axi_aresetn,
		input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_awaddr,
		input wire [2 : 0] s00_axi_awprot,
		input wire  s00_axi_awvalid,
		output wire  s00_axi_awready,
		input wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_wdata,
		input wire [(C_S00_AXI_DATA_WIDTH/8)-1 : 0] s00_axi_wstrb,
		input wire  s00_axi_wvalid,
		output wire  s00_axi_wready,
		output wire [1 : 0] s00_axi_bresp,
		output wire  s00_axi_bvalid,
		input wire  s00_axi_bready,
		input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_araddr,
		input wire [2 : 0] s00_axi_arprot,
		input wire  s00_axi_arvalid,
		output wire  s00_axi_arready,
		output wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_rdata,
		output wire [1 : 0] s00_axi_rresp,
		output wire  s00_axi_rvalid,
		input wire  s00_axi_rready
	);

	AXI4_register_file_v1_0_S00_AXI # (
		.C_S_AXI_DATA_WIDTH(C_S00_AXI_DATA_WIDTH),
		.C_S_AXI_ADDR_WIDTH(C_S00_AXI_ADDR_WIDTH)
	) AXI4_register_file_v1_0_S00_AXI_inst (
		.RW_REG0(RW_REG0),
		.RW_REG1(RW_REG1),
		.RW_REG2(RW_REG2),
		.RW_REG3(RW_REG3),
		.RO_REG0_IN(RO_REG0_IN),
		.RO_REG0_WE(RO_REG0_WE),
		.RO_REG1_IN(RO_REG1_IN),
		.RO_REG1_WE(RO_REG1_WE),
		.RO_REG2_IN(RO_REG2_IN),
		.RO_REG2_WE(RO_REG2_WE),
		.RO_REG3_IN(RO_REG3_IN),
		.RO_REG3_WE(RO_REG3_WE),
		.RO_REG0_RDINT(RO_REG0_RDINT),
		.RO_REG1_RDINT(RO_REG1_RDINT),
		.RO_REG2_RDINT(RO_REG2_RDINT),
		.RO_REG3_RDINT(RO_REG3_RDINT),
		.S_AXI_ACLK(s00_axi_aclk),
		.S_AXI_ARESETN(s00_axi_aresetn),
		.S_AXI_AWADDR(s00_axi_awaddr),
		.S_AXI_AWPROT(s00_axi_awprot),
		.S_AXI_AWVALID(s00_axi_awvalid),
		.S_AXI_AWREADY(s00_axi_awready),
		.S_AXI_WDATA(s00_axi_wdata),
		.S_AXI_WSTRB(s00_axi_wstrb),
		.S_AXI_WVALID(s00_axi_wvalid),
		.S_AXI_WREADY(s00_axi_wready),
		.S_AXI_BRESP(s00_axi_bresp),
		.S_AXI_BVALID(s00_axi_bvalid),
		.S_AXI_BREADY(s00_axi_bready),
		.S_AXI_ARADDR(s00_axi_araddr),
		.S_AXI_ARPROT(s00_axi_arprot),
		.S_AXI_ARVALID(s00_axi_arvalid),
		.S_AXI_ARREADY(s00_axi_arready),
		.S_AXI_RDATA(s00_axi_rdata),
		.S_AXI_RRESP(s00_axi_rresp),
		.S_AXI_RVALID(s00_axi_rvalid),
		.S_AXI_RREADY(s00_axi_rready)
	);

	endmodule
